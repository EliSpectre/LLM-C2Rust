#ifndef _VARS_H
#define _VARS_H
extern FILE *fp;
extern int stuCount;
extern long fileSize;
#endif