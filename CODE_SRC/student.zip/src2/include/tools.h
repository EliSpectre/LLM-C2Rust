#include <stdio.h> 

#ifndef _TOOLS_H
#define _TOOLS_H
extern long getFileSize(FILE *fp);  //获取文件大小
#endif