#include <stdio.h>

FILE *fp = NULL;  //文件指针
int stuCount = 0;  //总共有多少条学生信息
long fileSize = 0;  //文件长度（占用的字节数）