#include <stdio.h>
#include <stdlib.h>
#include "./include/config.h"
#include "./include/stu.h"
#include "./include/vars.h"
#include "./include/tools.h"


int main(){
    init();
    showAllStu();
    findStuByScores();
    return 0;
}
